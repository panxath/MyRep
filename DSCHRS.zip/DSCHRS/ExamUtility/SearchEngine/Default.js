//comment

var errmsg=new Array(7);
errmsg[0]="";
errmsg[1]="Invalid data in Average Assets Min field, please re-enter";
errmsg[2]="Invalid data in Average Assets Max field, please re-enter";
errmsg[3]="Invalid data in Average Assets Min and Max fields, please re-enter";
errmsg[4]="Average Assets Max must be greater than Average Assets Min, please re-enter";
errmsg[5]="No data in Average Assets Min but data exists in Average Assets Max, please correct";
errmsg[6]="Invalid data in Average Assets Min but data exists in Average Assets Max, please correct";

function ChangeDate(cdDate) {
	window.opener.document.forms(0).RepDte.value= cdDate;
}

function  Validate(){
		SetURL(2,"Find");
		document.forms.Find.submit();
}
function SetURL(site,formname) {
	var el_collection=eval("document.forms."+formname)
	if (site == '2') el_collection.action='initialfind1a.asp';
}
