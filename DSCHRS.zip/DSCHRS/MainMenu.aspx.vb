﻿Public Class MainMenu
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            'get user info into session variables
            Dim user As Object
            Dim oneGroup As Object
            Dim platForm As String = System.Web.Configuration.WebConfigurationManager.AppSettings("Platform").ToUpper
            'domain Academus
            If platForm = "DEVL" Then 'For development server, users have full access to all features.
                PanelDSCEmployee.Visible = True
                PanelSharpReport.Visible = True
                PanelDSCExam.Visible = True
                PanelAdmin.Visible = True
                PanelNone.Visible = False
            Else
                user = GetObject("WinNT://" & Replace(Request.ServerVariables("LOGON_USER"), "\", "/"))
                If platForm = "PROD" Then
                    PanelNone.Visible = False
                    PanelDSCEmployee.Visible = True
                Else
                    PanelNone.Visible = True
                End If
                'Response.Write (Request.ServerVariables("LOGON_USER"))
                'Case "R00DSCCORPORATEEMPLOYEES"
                'As long as the user has the access to this web site, (s)he must be DSC Employee
                For Each oneGroup In user.groups
                    Select Case UCase(oneGroup.name)
                        Case "R00DSCHOURSREADONLY_QA"
                            If platForm = "QUAL" Then
                                PanelDSCEmployee.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case "R01DSCHOURSREPORTS"
                            If platForm = "PROD" Then
                                PanelSharpReport.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case "R01DSCHOURSREPORTS_QA"
                            If platForm = "QUAL" Then
                                PanelSharpReport.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case "R01DSCEXAM"
                            If platForm = "PROD" Then
                                PanelDSCExam.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case "R01DSCEXAM_QA"
                            If platForm = "QUAL" Then
                                PanelDSCExam.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case "R01DSCHOURSADMIN_QA"
                            If platForm = "QUAL" Then
                                PanelAdmin.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case "R01DSCHOURSADMIN"
                            If platForm = "PROD" Then
                                PanelAdmin.Visible = True
                                PanelNone.Visible = False
                            End If
                        Case Else
                            'Response.Write UCase(oneGroup.name) & "<br>"
                    End Select
                    'Response.Write UCase(oneGroup.name) & "<br>"
                Next
            End If
        End If
    End Sub
End Class