//calDateFormat    = "yyyy/mm/dd";
calDateFormat    = "mm/dd/yyyy";


// CALENDAR COLORS
topBackground    = "white";         // BG COLOR OF THE TOP FRAME
bottomBackground = "white";         // BG COLOR OF THE BOTTOM FRAME
tableBGColor     = "black";         // BG COLOR OF THE BOTTOM FRAME'S TABLE
cellColor        = "lightgrey";     // TABLE CELL BG COLOR OF THE DATE CELLS IN THE BOTTOM FRAME
headingCellColor = "white";         // TABLE CELL BG COLOR OF THE WEEKDAY ABBREVIATIONS
headingTextColor = "black";         // TEXT COLOR OF THE WEEKDAY ABBREVIATIONS
dateColor        = "blue";          // TEXT COLOR OF THE LISTED DATES (1-28+)
focusColor       = "#ff0000";       // TEXT COLOR OF THE SELECTED DATE (OR CURRENT DATE)
hoverColor       = "darkred";       // TEXT COLOR OF A LINK WHEN YOU HOVER OVER IT
fontStyle        = "8pt arial, helvetica";           // TEXT STYLE FOR DATES
headingFontStyle = "bold 8pt arial, helvetica";      // TEXT STYLE FOR WEEKDAY ABBREVIATIONS
cen				 = "text-align: center; border: none";
image1			 = "../images/varrow.gif"
image2			 = "../images/arrow_right.gif"
// FORMATTING PREFERENCES
bottomBorder  = false;        // TRUE/FALSE (WHETHER TO DISPLAY BOTTOM CALENDAR BORDER)
tableBorder   = 0;            // SIZE OF CALENDAR TABLE BORDER (BOTTOM FRAME) 0=none



// END USER-EDITABLE SECTION -------------------------------------------------------



// DETERMINE BROWSER BRAND
var isNav = false;
var isIE  = false;

// ASSUME IT'S EITHER NETSCAPE OR MSIE
if (navigator.appName == "Netscape") {
    isNav = true;
}
else {
    isIE = true;
}

// GET CURRENTLY SELECTED LANGUAGE
selectedLanguage = navigator.language;

// PRE-BUILD PORTIONS OF THE CALENDAR WHEN THIS JS LIBRARY LOADS INTO THE BROWSER
buildCalParts();



// CALENDAR FUNCTIONS BEGIN HERE ---------------------------------------------------



// SET THE INITIAL VALUE OF THE GLOBAL DATE FIELD
function setDateField(dateField) {

    calDateField = dateField;
    inDate = dateField.value;
    setInitialDate();
    calDocTop    = buildTopCalFrame();
    calDocBottom = buildBottomCalFrame();
}


// SET THE INITIAL CALENDAR DATE TO TODAY OR TO THE EXISTING VALUE IN dateField
function setInitialDate() {
   
    calDate = new Date(inDate);
    if (isNaN(calDate)) {
        calDate = new Date();
    }

    calDay  = calDate.getDate();
	calDate.setDate(1);
}


// POPUP A WINDOW WITH THE CALENDAR IN IT

function showCalendar(dateField) {

    setDateField(dateField);
    calDocFrameset = 
        "<HTML><HEAD><TITLE>JavaScript Calendar</TITLE></HEAD>\n" +
        "<FRAMESET ROWS='70,*' FRAMEBORDER='0'>\n" +
        "  <FRAME NAME='topCalFrame' SRC='javascript:parent.opener.calDocTop' SCROLLING='no'>\n" +
        "  <FRAME NAME='bottomCalFrame' SRC='javascript:parent.opener.calDocBottom' SCROLLING='no'>\n" +
        "</FRAMESET>\n";
    
    
    top.newWin = window.open("javascript:parent.opener.calDocFrameset", "calWin", winPrefs);
    
    top.newWin.focus();
}

// CREATE THE TOP CALENDAR FRAME
function buildTopCalFrame() {

    // CREATE THE TOP FRAME OF THE CALENDAR
    var calDoc =
        "<HTML>" +
        "<HEAD>" +
        "</HEAD>" +
        "<BODY BGCOLOR='" + topBackground + "'>" +
        "<FORM NAME='calControl' onSubmit='return false;'>" +
        "<CENTER>" +
        "<TABLE CELLPADDING=0 CELLSPACING=1 BORDER=0>" +
        "<TR><TD >" +
        "<CENTER>" +
        "<IMG SRC='" + image1 + "' ALT='Previous Month' NAME='previousMonth' onClick='parent.opener.setPreviousMonth()'>" +
		//"<INPUT TYPE=BUTTON NAME='previousMonth' VALUE=' < '   onClick='parent.opener.setPreviousMonth()'>" +
        getMonthSelect() +
		"<IMG SRC='" + image2 + "' ALT='Next Month' NAME='nextMonth' onClick='parent.opener.setNextMonth()'>" +
		//"<INPUT TYPE=BUTTON NAME='nextMonth' VALUE=' > '   onClick='parent.opener.setNextMonth()'>" +
		"</TD>" +
        "</TR>" +
        "<TR>" +
        "<TD align=center>" +
        "<IMG SRC='" + image1 + "' ALT='Previous Year' NAME='previousYear' onClick='parent.opener.setPreviousYear()'>" +
		//"<INPUT TYPE=BUTTON NAME='previousYear' VALUE='<<'    onClick='parent.opener.setPreviousYear()'>" +
		"<INPUT style='" + cen + "' NAME='year' VALUE='" + calDate.getFullYear() + "'TYPE=TEXT SIZE=4 MAXLENGTH=4 onChange='parent.opener.setYear()'>" +
		"<IMG SRC='" + image2 + "' ALT='Next Year' NAME='nextYear' onClick='parent.opener.setNextYear()'>" +
		//"<INPUT TYPE=BUTTON NAME='nextYear' VALUE='>>'    onClick='parent.opener.setNextYear()'>" +
		"</CENTER>" +
     //"<INPUT TYPE=BUTTON NAME='today' VALUE='Today' onClick='parent.opener.setToday()'>" +
	    "</TD>" +
        "</TR>" +
        "</TABLE>" +
        "</CENTER>" +
        "</FORM>" +
        "</BODY>" +
        "</HTML>";

    return calDoc;
}


// CREATE THE BOTTOM CALENDAR FRAME 
// (THE MONTHLY CALENDAR)
function buildBottomCalFrame() {       
    
    var calDoc = calendarBegin;

    month   = calDate.getMonth();
    year    = calDate.getFullYear();

    day     = calDay;

    var i   = 0;

    var days = getDaysInMonth();

    if (day > days) {
        day = days;
    }

    var firstOfMonth = new Date (year, month, 1);
    var startingPos  = firstOfMonth.getDay();
    days += startingPos;

    var columnCount = 0;

    for (i = 0; i < startingPos; i++) {

        calDoc += blankCell;
	columnCount++;
    }

    var currentDay = 0;
    var dayType    = "weekday";

    for (i = startingPos; i < days; i++) {

	var paddingChar = "&nbsp;";

        if (i-startingPos+1 < 10) {
            padding = "&nbsp;&nbsp;";
        }
        else {
            padding = "&nbsp;";
        }

        currentDay = i-startingPos+1;

        if (currentDay == day) {
            dayType = "focusDay";
        }
        else {
            dayType = "weekDay";
        }

        // ADD THE DAY TO THE CALENDAR STRING
        calDoc += "<TD align=center bgcolor='" + cellColor + "'>" +
                  "<a class='" + dayType + "' href='javascript:parent.opener.returnDate(" + 
                  currentDay + ")'>" + padding + currentDay + paddingChar + "</a></TD>";

        columnCount++;

        if (columnCount % 7 == 0) {
            calDoc += "</TR><TR>";
        }
    }

    for (i=days; i<42; i++)  {

        calDoc += blankCell;
	columnCount++;

        if (columnCount % 7 == 0) {
            calDoc += "</TR>";
            if (i<41) {
                calDoc += "<TR>";
            }
        }
    }

    calDoc += calendarEnd;

    return calDoc;
}


// WRITE THE MONTHLY CALENDAR TO THE BOTTOM CALENDAR FRAME
function writeCalendar() {

    calDocBottom = buildBottomCalFrame();

    top.newWin.frames['bottomCalFrame'].document.open();
    top.newWin.frames['bottomCalFrame'].document.write(calDocBottom);
    top.newWin.frames['bottomCalFrame'].document.close();
}


// SET THE CALENDAR TO TODAY'S DATE AND DISPLAY THE NEW CALENDAR
function setToday() {

    calDate = new Date();

    var month = calDate.getMonth();
    var year  = calDate.getFullYear();

    top.newWin.frames['topCalFrame'].document.calControl.month.value = month;

    top.newWin.frames['topCalFrame'].document.calControl.year.value = year;

    writeCalendar();
}


// SET THE GLOBAL DATE TO THE NEWLY ENTERED YEAR AND REDRAW THE CALENDAR
function setYear() {

    var year  = top.newWin.frames['topCalFrame'].document.calControl.year.value;

    if (isFourDigitYear(year)) {
        calDate.setFullYear(year);
        writeCalendar();
    }
    else {
        top.newWin.frames['topCalFrame'].document.calControl.year.focus();
        top.newWin.frames['topCalFrame'].document.calControl.year.select();
    }
}


function setCurrentMonth() {
  monthArray = new Array('January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December');
    

//alert(top.newWin.frames['topCalFrame'].document.calControl.month.value)

    var monthvalue = top.newWin.frames['topCalFrame'].document.calControl.month.value;

      for (i in monthArray) {
        
      if (monthvalue == monthArray(i)) {
      //alert('value='+ i)
       month = i+1 ;
       exit;
        }
        
    }
    
    calDate.setMonth(1);
    writeCalendar();
}


// SET THE GLOBAL DATE TO THE PREVIOUS YEAR AND REDRAW THE CALENDAR
function setPreviousYear() {

    var year  = top.newWin.frames['topCalFrame'].document.calControl.year.value;

    if (isFourDigitYear(year) && year > 1000) {
        year--;
        calDate.setFullYear(year);
        top.newWin.frames['topCalFrame'].document.calControl.year.value = year;
        writeCalendar();
    }
}


// SET THE GLOBAL DATE TO THE PREVIOUS MONTH AND REDRAW THE CALENDAR
function setPreviousMonth() {
	var i;
	monthArray = new Array('January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December');
    

	var monthvalue = top.newWin.frames['topCalFrame'].document.calControl.month.value;
      
      for (i=0;i<12;i++) {
       if (monthvalue == monthArray[i]) {
       month = i  ;
       break;
       }
        
    }
    
    var year  = top.newWin.frames['topCalFrame'].document.calControl.year.value;
    if (isFourDigitYear(year)) {
        //var month = top.newWin.frames['topCalFrame'].document.calControl.month.value;

        if (month == 0) {
            month = 11;
            if (year > 1000) {
                year--;
                calDate.setFullYear(year);
                top.newWin.frames['topCalFrame'].document.calControl.year.value = year;
            }
        }
        else {
            month--;
        }
        calDate.setMonth(month);
        top.newWin.frames['topCalFrame'].document.calControl.month.value = monthArray[month];
        writeCalendar();
    }
}


// SET THE GLOBAL DATE TO THE NEXT MONTH AND REDRAW THE CALENDAR
function setNextMonth() {
var i;

monthArray = new Array('January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December');
    
 var monthvalue = top.newWin.frames['topCalFrame'].document.calControl.month.value;
      
      for (i=0;i<12;i++) {
       if (monthvalue == monthArray[i]) {
       month = i  ;
       break;
       }
        
    }

    var year = top.newWin.frames['topCalFrame'].document.calControl.year.value;

    if (isFourDigitYear(year)) {
        //var month = top.newWin.frames['topCalFrame'].document.calControl.month.value;
        
        
        if (month == 11) {
            month = 0;
            year++;
            calDate.setFullYear(year);
            top.newWin.frames['topCalFrame'].document.calControl.year.value = year;
        }
        else {
            month++;
        }
        calDate.setMonth(month);
        top.newWin.frames['topCalFrame'].document.calControl.month.value = monthArray[month];
        writeCalendar();
    }
}


// SET THE GLOBAL DATE TO THE NEXT YEAR AND REDRAW THE CALENDAR
function setNextYear() {

    var year  = top.newWin.frames['topCalFrame'].document.calControl.year.value;
    if (isFourDigitYear(year)) {
        year++;
        calDate.setFullYear(year);
        top.newWin.frames['topCalFrame'].document.calControl.year.value = year;
        writeCalendar();
    }
}


// GET NUMBER OF DAYS IN MONTH
function getDaysInMonth()  {

    var days;
    var month = calDate.getMonth()+1;
    var year  = calDate.getFullYear();

    if (month==1 || month==3 || month==5 || month==7 || month==8 ||
        month==10 || month==12)  {
        days=31;
    }
    else if (month==4 || month==6 || month==9 || month==11) {
        days=30;
    }
    else if (month==2)  {
        if (isLeapYear(year)) {
            days=29;
        }
        else {
            days=28;
        }
    }
    return (days);
}


// CHECK TO SEE IF YEAR IS A LEAP YEAR
function isLeapYear (Year) {

    if (((Year % 4)==0) && ((Year % 100)!=0) || ((Year % 400)==0)) {
        return (true);
    }
    else {
        return (false);
    }
}


// ENSURE THAT THE YEAR IS FOUR DIGITS IN LENGTH
function isFourDigitYear(year) {

    if (year.length != 4) {
        top.newWin.frames['topCalFrame'].document.calControl.year.value = calDate.getFullYear();
        top.newWin.frames['topCalFrame'].document.calControl.year.select();
        top.newWin.frames['topCalFrame'].document.calControl.year.focus();
    }
    else {
        return true;
    }
}


// BUILD THE MONTH SELECT LIST
function getMonthSelect() {

   
        monthArray = new Array('January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December');
    

    var activeMonth = calDate.getMonth();

    for (i in monthArray) {
        
      if (i == activeMonth) {
      monthSelect = "<INPUT style='" + cen + "' NAME='month' value='"+monthArray[i]+"' TYPE=TEXT SIZE=10 MAXLENGTH=4 onChange='parent.opener.setCurrentMonth()'>" ;
	  }
	}	
      
    return monthSelect;
}


function createWeekdayList() {

        weekdayList  = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
        weekdayArray = new Array('S','M','T','W','T','F','S');
    

    var weekdays = "<TR BGCOLOR='" + headingCellColor + "'>";

    for (i in weekdayArray) {

        weekdays += "<TD class='heading' align=center>" + weekdayArray[i] + "</TD>";
    }
    weekdays += "</TR>";

    return weekdays;
}


function buildCalParts() {

    weekdays = createWeekdayList();

    blankCell = "<TD align=center bgcolor='" + cellColor + "'>&nbsp;&nbsp;&nbsp;</TD>";

    calendarBegin =
        "<HTML>" +
        "<HEAD>" +
        "<STYLE type='text/css'>" +
        "<!--" +
        "TD.heading { text-decoration: none; color:" + headingTextColor + "; font: " + headingFontStyle + "; }" +
        "A.focusDay:link { color: " + focusColor + "; text-decoration: none; font: " + fontStyle + "; }" +
	"A.focusDay:visited { color: red; text-decoration: none; font-family: arial; font-size: 8pt ; }" +
        "A.focusDay:hover { color: " + focusColor + "; text-decoration: none; font: " + fontStyle + "; }" +
        "A.weekday:link { color: " + dateColor + "; text-decoration: none; font: " + fontStyle + "; }" +
	"A.weekday:visited { color: blue; text-decoration: none; font-family: arial; font-size: 8pt ; }" +
        "A.weekday:hover { color: " + hoverColor + "; text-decoration: none; font: " + fontStyle + "; }" +
        "-->" +
        "</STYLE>" +
        "</HEAD>" +
        "<BODY onload= 'focus();' BGCOLOR='" + bottomBackground + "'" +
        "<CENTER>";

        if (isNav) {
            calendarBegin += 
                "<TABLE CELLPADDING=0 CELLSPACING=1 BORDER=" + tableBorder + " ALIGN=CENTER BGCOLOR='" + tableBGColor + "'><TR><TD>";
        }

        calendarBegin +=
            "<TABLE CELLPADDING=0 CELLSPACING=1 BORDER=" + tableBorder + " ALIGN=CENTER BGCOLOR='" + tableBGColor + "'>" +
            weekdays +
            "<TR>";


    calendarEnd = "";

        if (bottomBorder) {
            calendarEnd += "<TR></TR>";
        }

        if (isNav) {
            calendarEnd += "</TD></TR></TABLE>";
        }

        calendarEnd +=
            "</TABLE>" +
            "</CENTER>" +
            "</BODY>" +
            "</HTML>";
}


function jsReplace(inString, find, replace) {

    var outString = "";

    if (!inString) {
        return "";
    }

    if (inString.indexOf(find) != -1) {
        t = inString.split(find);

        return (t.join(replace));
    }
    else {
        return inString;
    }
}


function doNothing() {
}


function makeTwoDigit(inValue) {

    var numVal = parseInt(inValue, 10);

    if (numVal < 10) {

        return("0" + numVal);
    }
    else {
        return numVal;
    }
}


// SET FIELD VALUE TO THE DATE SELECTED AND CLOSE THE CALENDAR WINDOW
function returnDate(inDay)
{

    calDate.setDate(inDay);

    var day           = calDate.getDate();
    var month         = calDate.getMonth()+1;
    var year          = calDate.getFullYear();
    var monthString   = monthArray[calDate.getMonth()];
    var monthAbbrev   = monthString.substring(0,3);
    var weekday       = weekdayList[calDate.getDay()];
    var weekdayAbbrev = weekday.substring(0,3);

    outDate = calDateFormat;

    if (calDateFormat.indexOf("DD") != -1) {
        day = makeTwoDigit(day);
        outDate = jsReplace(outDate, "DD", day);
    }
    else if (calDateFormat.indexOf("dd") != -1) {
		day = makeTwoDigit(day);
        outDate = jsReplace(outDate, "dd", day);
    }


    if (calDateFormat.indexOf("MM") != -1) {
        month = makeTwoDigit(month);
        outDate = jsReplace(outDate, "MM", month);
    }
    else if (calDateFormat.indexOf("mm") != -1) {
		month = makeTwoDigit(month);
        outDate = jsReplace(outDate, "mm", month);
    }

    if (calDateFormat.indexOf("yyyy") != -1) {
        outDate = jsReplace(outDate, "yyyy", year);
    }
    
    calDateField.value = outDate;

    calDateField.focus();

    top.newWin.close()
}
