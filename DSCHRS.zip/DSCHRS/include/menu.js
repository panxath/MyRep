function loadBottomMap() {
  document.write('<TABLE ALIGN=CENTER BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="70%">')
  document.write('<TR ALIGN=LEFT VALIGN=TOP>')
  document.write('<TD ALIGN=LEFT VALIGN=TOP WIDTH="20%">')
  //document.write('<IMG SRC="images/sideback.gif" HEIGHT=99 WIDTH=154>')
  document.write('</TD>')
  document.write('<TD ALIGN=LEFT VALIGN=TOP>')
  document.write('<IMG SRC="images/corplink.gif" HEIGHT=28 WIDTH=474><br>')
  document.write('<a href="http://s00iis101/images/buttbar.map">')
  document.write('<img src="images/buttbar.gif" hspace=30 vspace=4 alt="Graphical Navigation Button Bar" border="0" width="394" height="58" ismap></a>')
  document.write('</TD>')
  document.write('</TR>')
  document.write('</TABLE>')
}


function show(object) {
  if (document.layers && document.layers[object])
    document.layers[object].visibility = 'visible';
  else if (document.all)
    document.all[object].style.visibility = 'visible';
}

function hide(object) {
//alert('Test');
  if (document.layers && document.layers[object])
    document.layers[object].visibility = 'hidden';    
  else if (document.all)
    document.all[object].style.visibility = 'hidden';
}
