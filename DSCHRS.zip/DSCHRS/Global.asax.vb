﻿Imports System.Web.SessionState
Imports System.Data.SqlClient
Imports System.Web.Configuration

Public Class Global_asax
    Inherits System.Web.HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application is started
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started
        Dim con As SqlConnection
        Dim com As SqlCommand
        Try
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("DSCHRSConnectionString").ConnectionString)
            con.Open()
            com = New SqlCommand("P_INS_USER_APPL_ACCS", con)
            com.ExecuteNonQuery()
            con.Close()
        Catch ex As Exception

        End Try
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

End Class