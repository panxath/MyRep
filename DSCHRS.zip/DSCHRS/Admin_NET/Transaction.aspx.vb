﻿Imports System.Data.SqlClient

Public Class Transaction
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        TextTransID.Attributes.Add("onkeypress", "return isNumberKey(event);")
    End Sub
    Public Sub ResetGridViewAll()
        SqlDataSourceDSCHRS.SelectParameters("MODE").DefaultValue = "SEARCH"
        SqlDataSourceDSCHRS.SelectParameters("TC_ID").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("TCODE_ID").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("DESC").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("BNK_IND").DefaultValue = " "
        GridViewAll.DataBind()
    End Sub
    'Rest Transaction update form
    Public Sub resetTransactionForm()
        TextNewUpdate.Text = "NEW"
        TextTransID.Text = ""
        TextTransID.ReadOnly = False
        TextTransID.BackColor = Drawing.Color.Empty
        TextTransCode.Text = ""
        TextTransDesc.Text = ""
        DDLBankInd.SelectedIndex = 0
    End Sub
    'validate  form before save
    Public Function ValidateForm() As Boolean
        Dim sErrorMsg As String
        ValidateForm = True
        sErrorMsg = ""
        If TextTransID.Text.Trim() = "" Then
            ValidateForm = False
            TextTransID.Focus()
            sErrorMsg = "Please enter Transaction ID"
        ElseIf TextTransCode.Text.Trim() = "" Then
            ValidateForm = False
            TextTransCode.Focus()
            sErrorMsg = "Please enter Transaction Code"
        ElseIf TextTransDesc.Text.Trim() = "" Then
            ValidateForm = False
            TextTransDesc.Focus()
            sErrorMsg = "Please enter Transaction Desc"
        ElseIf DDLBankInd.SelectedIndex = 0 Then
            ValidateForm = False
            DDLBankInd.Focus()
            sErrorMsg = "Please select Bank Indicator"
        End If

        If ValidateForm = True Then
            Try
                Integer.Parse(TextTransID.Text.Trim())
            Catch ex As Exception
                ValidateForm = False
                TextTransID.Focus()
                sErrorMsg = "Please only enter numbers for Transaction ID"
            End Try
        End If

        If ValidateForm = False Then
            CType(Me.Master, Admin).UserMsgBox(sErrorMsg)
        End If

    End Function
    'reset
    Protected Sub ImageButtonEmpty_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonEmpty.Click
        resetTransactionForm()
        ResetGridViewAll()
        PanelTransAll.Visible = "false"
    End Sub
    Protected Sub ImageButtonSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonSearch.Click
        Dim sTransID As String
        Dim sTransCode As String
        Dim sDesc As String
        Dim sBankInd As String

        sTransID = TextTransID.Text.Trim()
        sTransCode = TextTransCode.Text.Trim()
        sDesc = TextTransDesc.Text.Trim()
        sBankInd = DDLBankInd.SelectedValue.Trim()



        If TextTransID.Text.Trim() = "" Then
            sTransID = " "
        End If
        If TextTransCode.Text.Trim() = "" Then
            sTransCode = " "
        End If
        If TextTransDesc.Text.Trim() = "" Then
            sDesc = " "
        End If
        If DDLBankInd.SelectedValue.Trim() = "" Then
            sBankInd = " "
        End If

        SqlDataSourceDSCHRS.SelectParameters("MODE").DefaultValue = "SEARCH"
        SqlDataSourceDSCHRS.SelectParameters("TC_ID").DefaultValue = sTransID
        SqlDataSourceDSCHRS.SelectParameters("TCODE_ID").DefaultValue = sTransCode
        SqlDataSourceDSCHRS.SelectParameters("DESC").DefaultValue = sDesc
        SqlDataSourceDSCHRS.SelectParameters("BNK_IND").DefaultValue = sBankInd


        GridViewAll.DataBind()
        PanelTransAll.Visible = "true"

    End Sub
    'save
    Protected Sub ImageButtonInsert_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonInsert.Click
        If ValidateForm() = False Then
            Exit Sub
        End If


        Dim connString = ConfigurationManager.ConnectionStrings("DSCHRSConnectionString")
        Dim sqlConn As SqlConnection
        Dim sqlCmd As SqlCommand
        Dim sqlReader As SqlDataReader
        Dim sMessage As String
        Dim sResult As String
        'Dim sqlPara As SqlParameter

        sMessage = ""
        sResult = ""

        sqlConn = New SqlConnection()
        sqlConn.ConnectionString = connString.ConnectionString
        sqlConn.Open()
        sqlCmd = New SqlCommand()
        sqlCmd.CommandType = CommandType.StoredProcedure
        sqlCmd.Connection = sqlConn

        Try
            sqlCmd.CommandText = "P_INS_UPD_TRANS"
            'sqlPara = sqlCmd.Parameters.Add("@TransID", SqlDbType.Decimal, 10)
            'sqlPara.Precision = 10
            'sqlPara.Scale = 0

            'sqlPara.Value = TextTransID.Text.Trim()
            sqlCmd.Parameters.AddWithValue("@TransID", TextTransID.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@TransCodeID", TextTransCode.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@TransDesc", TextTransDesc.Text.Trim())
            If DDLBankInd.SelectedValue.Trim() = "" Then
                sqlCmd.Parameters.AddWithValue("@BankInd", DBNull.Value)
            Else
                sqlCmd.Parameters.AddWithValue("@BankInd", DDLBankInd.SelectedValue.Trim())
            End If
            sqlCmd.Parameters.AddWithValue("@UserID", System.Security.Principal.WindowsIdentity.GetCurrent().Name)

            sqlReader = sqlCmd.ExecuteReader()
            If sqlReader.HasRows Then
                sqlReader.Read()
                sResult = sqlReader.GetString(0)
                sMessage = sqlReader.GetString(1)
            End If
            If sResult = "1" Then
                sMessage = "Data Saved Successfully"
                resetTransactionForm()
                GridViewAll.DataBind()
                GridViewToDo.DataBind()
            Else
                If TextTransID.ReadOnly Then
                    TextTransID.Focus()
                Else
                    TextTransID.Focus()
                End If
            End If


        Catch ex As Exception
            CType(Me.Master, Admin).UserMsgBox(ex.Message)
        Finally
            sqlConn.Close()
            sqlConn = Nothing
            sqlReader = Nothing
            sqlCmd = Nothing

        End Try

        If (sMessage <> "") Then
            CType(Me.Master, Admin).UserMsgBox(sMessage)
        End If

    End Sub
    Protected Sub GridViewAll_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewAll.RowCommand

        If (e.CommandName = "cmdUpdAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetTransactionForm()
            TextNewUpdate.Text = "UPDATE"
            TextTransID.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextTransID.ReadOnly = True
            TextTransID.BackColor = Drawing.Color.DarkGray
            TextTransCode.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextTransDesc.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(3).Text.Trim())
            CType(Me.Master, Admin).setDropdownList(Me.DDLBankInd, HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(4).Text.Trim()))
            TextTransCode.Focus()

        End If


    End Sub
    'click update for missing activity code
    Protected Sub GridViewToDo_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewToDo.RowCommand

        If (e.CommandName = "cmdAddAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetTransactionForm()
            TextNewUpdate.Text = "UPDATE"
            TextTransID.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextTransID.ReadOnly = True
            TextTransID.BackColor = Drawing.Color.DarkGray
            TextTransCode.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextTransDesc.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(3).Text.Trim())
            CType(Me.Master, Admin).setDropdownList(Me.DDLBankInd, HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(4).Text.Trim()))
            TextTransCode.Focus()
        End If
    End Sub
End Class