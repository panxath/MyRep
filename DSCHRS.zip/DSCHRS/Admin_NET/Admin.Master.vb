﻿Public Class Admin
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    'server side message box
    Public Sub UserMsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control = Nothing

        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))

    End Sub
    'set the select value
    Public Sub setDropdownList(ByVal objControl As DropDownList, ByVal sValue As String)
        If String.IsNullOrEmpty(sValue) = True Then
            objControl.SelectedIndex = 0
        Else
            For i = 1 To objControl.Items.Count - 1 Step 1
                If objControl.Items(i).Value.Trim().ToLower() = sValue.Trim().ToLower() Then
                    objControl.SelectedIndex = i
                    Exit For
                End If
            Next
        End If
    End Sub
End Class