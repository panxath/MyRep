﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Positions_Group
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    'Rest Posistions Group update form
    Public Sub resetPositionsGroupForm()
        TextNewUpdate.Text = "NEW"
        TextTitleDesc.Text = ""
        TextTitleDesc.ReadOnly = False
        TextTitleDesc.BackColor = Drawing.Color.Empty
        TextPosGroupCode.Text = ""
        TextPosGroupDesc.Text = ""
        TextOldPosGroupCode.Text = ""
        DDLRegion.SelectedIndex = 0
    End Sub
    Public Sub ResetGridViewAll()
        SqlDataSourceDSCHRS.SelectParameters("MODE").DefaultValue = "EXIST"
        SqlDataSourceDSCHRS.SelectParameters("POS_GROUP_CODE").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("POS_TITLE_DESC").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("POS_GROUP_DESC").DefaultValue = " "
        GridViewAll.DataBind()
    End Sub
    'validate acivitiy form before save
    Public Function ValidateForm() As Boolean
        Dim sErrorMsg As String
        ValidateForm = True
        sErrorMsg = ""
        If TextTitleDesc.Text.Trim() = "" Then
            ValidateForm = False
            TextTitleDesc.Focus()
            sErrorMsg = "Please enter Positions Title Desc"
        ElseIf TextPosGroupCode.Text.Trim() = "" Then
            ValidateForm = False
            TextPosGroupCode.Focus()
            sErrorMsg = "Please enter Positions Group Code"
        ElseIf TextPosGroupDesc.Text.Trim() = "" Then
            ValidateForm = False
            TextPosGroupDesc.Focus()
            sErrorMsg = "Please enter Positions Group Desc"
        End If
        If ValidateForm = False Then
            CType(Me.Master, Admin).UserMsgBox(sErrorMsg)
        End If

    End Function
    'reset
    Protected Sub ImageButtonEmpty_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonEmpty.Click
        resetPositionsGroupForm()
        ResetGridViewAll()
        PanelPOSGroupAll.Visible = "false"
    End Sub
    Protected Sub ImageButtonSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonSearch.Click
        Dim sPOSGroupCode As String
        Dim sPosTitleDesc As String
        Dim sPosGroupDesc As String

        sPOSGroupCode = TextPosGroupCode.Text.Trim()
        sPosTitleDesc = TextTitleDesc.Text.Trim()
        sPosGroupDesc = TextPosGroupDesc.Text.Trim()

        'If (sProgramCode = "" And sActivityID = "" ) Then
        'CType(Me.Master, Admin).UserMsgBox("Please enter Program Code or Activity ID or Both")
        ' Else

        If TextPosGroupCode.Text.Trim() = "" Then
            sPOSGroupCode = " "
        End If
        If TextTitleDesc.Text.Trim() = "" Then
            sPosTitleDesc = " "
        End If
        If TextPosGroupDesc.Text.Trim() = "" Then
            sPosGroupDesc = " "
        End If
        SqlDataSourceDSCHRS.SelectParameters("MODE").DefaultValue = "EXIST"
        SqlDataSourceDSCHRS.SelectParameters("POS_GROUP_CODE").DefaultValue = sPOSGroupCode
        SqlDataSourceDSCHRS.SelectParameters("POS_TITLE_DESC").DefaultValue = sPosTitleDesc
        SqlDataSourceDSCHRS.SelectParameters("POS_GROUP_DESC").DefaultValue = sPosGroupDesc

        GridViewAll.DataBind()
        PanelPOSGroupAll.Visible = "true"
        'End If
    End Sub
    'save
    Protected Sub ImageButtonInsert_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonInsert.Click
        If ValidateForm() = False Then
            Exit Sub
        End If


        Dim connString = ConfigurationManager.ConnectionStrings("DSCHRSConnectionString")
        Dim sqlConn As SqlConnection
        Dim sqlCmd As SqlCommand
        Dim sqlReader As SqlDataReader
        Dim sMessage As String
        Dim sResult As String

        sMessage = ""
        sResult = ""

        sqlConn = New SqlConnection()
        sqlConn.ConnectionString = connString.ConnectionString
        sqlConn.Open()
        sqlCmd = New SqlCommand()
        sqlCmd.CommandType = CommandType.StoredProcedure
        sqlCmd.Connection = sqlConn

        Try
            sqlCmd.CommandText = "P_INS_UPD_Position_Group"
            sqlCmd.CommandTimeout = 3000

            If TextPosGroupCode.Text.Trim.ToLower = TextOldPosGroupCode.Text.Trim().ToLower Then
                'update but no Position and Group code change
                sqlCmd.Parameters.AddWithValue("@Mode", "NO")
            Else
                sqlCmd.Parameters.AddWithValue("@Mode", TextNewUpdate.Text.Trim())
            End If
            sqlCmd.Parameters.AddWithValue("@POS_GROUP_CODE", TextPosGroupCode.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@POS_TITLE_DESC", TextTitleDesc.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@POS_GROUP_DESC", TextPosGroupDesc.Text.Trim())
           
            If DDLRegion.SelectedValue.Trim() = "" Then
                sqlCmd.Parameters.AddWithValue("@REGIONCODE", DBNull.Value)
            Else
                sqlCmd.Parameters.AddWithValue("@REGIONCODE", DDLRegion.SelectedValue.Trim())
            End If
            sqlCmd.Parameters.AddWithValue("@SystemUserID", System.Security.Principal.WindowsIdentity.GetCurrent().Name)
            sqlCmd.Parameters.AddWithValue("@OLD_POS_GROUP_CODE", TextOldPosGroupCode.Text.Trim())
            sqlReader = sqlCmd.ExecuteReader()
            If sqlReader.HasRows Then
                sqlReader.Read()
                sResult = sqlReader.GetString(0)
                sMessage = sqlReader.GetString(1)
            End If
            If sResult = "1" Then
                sMessage = "Data Saved Successfully"
                resetPositionsGroupForm()
                GridViewAll.DataBind()
                GridViewToDo.DataBind()
            Else
                If TextTitleDesc.ReadOnly Then
                    TextPosGroupCode.Focus()
                Else
                    TextTitleDesc.Focus()
                End If
            End If


        Catch ex As Exception
            CType(Me.Master, Admin).UserMsgBox(ex.Message)
        Finally
            sqlConn.Close()
            sqlConn = Nothing
            sqlReader = Nothing
            sqlCmd = Nothing
        End Try

        If (sMessage <> "") Then
            CType(Me.Master, Admin).UserMsgBox(sMessage)
        End If

    End Sub
    Protected Sub GridViewAll_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewAll.RowCommand

        If (e.CommandName = "cmdUpdAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetPositionsGroupForm()
            TextNewUpdate.Text = "UPDATE"
            TextTitleDesc.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextTitleDesc.ReadOnly = True
            TextTitleDesc.BackColor = Drawing.Color.DarkGray
            TextPosGroupCode.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextPosGroupDesc.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(3).Text.Trim())
            TextOldPosGroupCode.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(1).Text.Trim())
            CType(Me.Master, Admin).setDropdownList(Me.DDLRegion, HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(4).Text.Trim()))
            TextPosGroupCode.Focus()

        End If


    End Sub
    'click update for missing activity code
    Protected Sub GridViewToDo_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewToDo.RowCommand

        If (e.CommandName = "cmdAddAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetPositionsGroupForm()
            TextNewUpdate.Text = "UPDATE"
            TextTitleDesc.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextTitleDesc.ReadOnly = True
            TextTitleDesc.BackColor = Drawing.Color.DarkGray
            TextPosGroupCode.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextPosGroupDesc.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(3).Text.Trim())
            TextOldPosGroupCode.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(1).Text.Trim())
            CType(Me.Master, Admin).setDropdownList(Me.DDLRegion, HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(4).Text.Trim()))
            TextPosGroupCode.Focus()
        End If
    End Sub
End Class