﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Activity
    Inherits System.Web.UI.Page
    'click update for exist activity code
    Protected Sub GridViewAll_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewAll.RowCommand

        If (e.CommandName = "cmdUpdAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetActivityForm()
            TextNewUpdate.Text = "UPDATE"
            TextProgramCode.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextProgramCode.ReadOnly = True
            TextProgramCode.BackColor = Drawing.Color.DarkGray
            TextActivityID.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextActivityID.ReadOnly = True
            TextActivityID.BackColor = Drawing.Color.DarkGray
            TextActivityCode.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(3).Text.Trim())
            TextActivityDesc.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(4).Text.Trim())
            DDLHRType.SelectedIndex = 0
            If (String.IsNullOrEmpty(HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(6).Text)) = False) Then
                If (GridViewAll.Rows(currentRowIndex).Cells(6).Text.Trim().ToUpper() = "Y") Then
                    DDLHRType.SelectedIndex = 1
                ElseIf (GridViewAll.Rows(currentRowIndex).Cells(6).Text.Trim().ToUpper() = "N") Then
                    DDLHRType.SelectedIndex = 2
                ElseIf (GridViewAll.Rows(currentRowIndex).Cells(6).Text.Trim().ToUpper() = "O") Then
                    DDLHRType.SelectedIndex = 3
                End If
            End If

            CType(Me.Master, Admin).setDropdownList(Me.DDLExamActivity, HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(5).Text.Trim()))
            TextOldActCode.Text = HttpUtility.HtmlEncode(TextActivityCode.Text)
            TextActivityCode.Focus()

        End If


    End Sub
    'click update for missing activity code
    Protected Sub GridViewToDo_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewToDo.RowCommand

        If (e.CommandName = "cmdAddAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetActivityForm()
            TextNewUpdate.Text = "MISS"
            TextActivityDesc.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(4).Text.Trim()) + " - " + HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextProgramCode.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextProgramCode.ReadOnly = True
            TextProgramCode.BackColor = Drawing.Color.DarkGray
            TextActivityID.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(3).Text.Trim())
            TextActivityID.ReadOnly = True
            TextActivityID.BackColor = Drawing.Color.DarkGray
            GetExistActivity()
            TextActivityCode.Focus()
        End If
    End Sub
    'Rest Activity update form
    Public Sub resetActivityForm()
        TextNewUpdate.Text = "NEW"
        TextProgramCode.Text = ""
        TextProgramCode.ReadOnly = False
        TextProgramCode.BackColor = Drawing.Color.Empty
        TextActivityID.Text = ""
        TextActivityID.ReadOnly = False
        TextActivityID.BackColor = Drawing.Color.Empty
        TextActivityCode.Text = ""
        TextActivityDesc.Text = ""
        TextOldActCode.Text = ""
        DDLHRType.SelectedIndex = 2
        CType(Me.Master, Admin).setDropdownList(Me.DDLExamActivity, "NO")
    End Sub
    Private Sub GetExistActivity()
        Dim connString = ConfigurationManager.ConnectionStrings("DSCHRSConnectionString")
        Dim sqlConn As SqlConnection
        Dim sqlCmd As SqlCommand
        Dim sqlReader As SqlDataReader

        sqlConn = New SqlConnection()
        sqlConn.ConnectionString = connString.ConnectionString
        sqlConn.Open()
        sqlCmd = New SqlCommand()
        sqlCmd.CommandType = CommandType.StoredProcedure
        sqlCmd.Connection = sqlConn
        Try
            sqlCmd.CommandText = "P_SEL_ACT"
            sqlCmd.Parameters.AddWithValue("@MODE", "")
            sqlCmd.Parameters.AddWithValue("@PROGRAM_CODE", TextProgramCode.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ACTIVITY_ID", TextActivityID.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ACTIVITY_CODE", "")

            sqlReader = sqlCmd.ExecuteReader()
            If sqlReader.HasRows Then
                sqlReader.Read()
                TextActivityCode.Text = HttpUtility.HtmlEncode(sqlReader.GetString(0).Trim())
                TextActivityDesc.Text = HttpUtility.HtmlEncode(sqlReader.GetString(1).Trim())

                If (sqlReader.GetString(2).Trim().ToUpper() = "Y") Then
                    DDLHRType.SelectedIndex = 1
                ElseIf (sqlReader.GetString(2).Trim().ToUpper() = "N") Then
                    DDLHRType.SelectedIndex = 2
                ElseIf (sqlReader.GetString(2).Trim().ToUpper() = "O") Then
                    DDLHRType.SelectedIndex = 3
                End If
                CType(Me.Master, Admin).setDropdownList(Me.DDLExamActivity, sqlReader.GetString(3))
            End If
        Catch ex As Exception
            CType(Me.Master, Admin).UserMsgBox(ex.Message)
        Finally
            sqlConn.Close()
            sqlConn = Nothing
            sqlReader = Nothing
            sqlCmd = Nothing
        End Try
    End Sub
    'reset
    Protected Sub ImageButtonEmpty_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonEmpty.Click
        resetActivityForm()
        ResetGridViewAll()
        PanelActivityAll.Visible = "false"
    End Sub
    'save
    Protected Sub ImageButtonInsert_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonInsert.Click
        If ValidateForm() = False Then
            Exit Sub
        End If

        Dim connString = ConfigurationManager.ConnectionStrings("DSCHRSConnectionString")
        Dim sqlConn As SqlConnection
        Dim sqlCmd As SqlCommand
        Dim sqlReader As SqlDataReader
        Dim sMessage As String
        Dim sResult As String


        sMessage = ""
        sResult = ""

        sqlConn = New SqlConnection()
        sqlConn.ConnectionString = connString.ConnectionString
        sqlConn.Open()
        sqlCmd = New SqlCommand()
        sqlCmd.CommandType = CommandType.StoredProcedure
        sqlCmd.Connection = sqlConn


        Try
            sqlCmd.CommandText = "P_INS_UPD_ACT"
            sqlCmd.Parameters.AddWithValue("@Mode", TextNewUpdate.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ProgramCode", TextProgramCode.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ActivityID", TextActivityID.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ActCode", TextActivityCode.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ExamHRType", DDLHRType.SelectedValue.Trim())

            If DDLExamActivity.SelectedValue.Trim() = "" Then
                sqlCmd.Parameters.AddWithValue("@ExamActInd", DBNull.Value)
            Else
                sqlCmd.Parameters.AddWithValue("@ExamActInd", DDLExamActivity.SelectedValue.Trim())
            End If
            sqlCmd.Parameters.AddWithValue("@ActDesc", TextActivityDesc.Text.Trim())

            sqlReader = sqlCmd.ExecuteReader()
            If sqlReader.HasRows Then
                sqlReader.Read()
                sResult = sqlReader.GetString(0)
                sMessage = sqlReader.GetString(1)
            End If
            If sResult = "1" Then
                sMessage = "Data Saved Successfully"
                resetActivityForm()
                GridViewAll.DataBind()
                GridViewToDo.DataBind()
            Else
                If TextProgramCode.ReadOnly Then
                    TextActivityCode.Focus()
                Else
                    TextProgramCode.Focus()
                End If
            End If


        Catch ex As Exception
            CType(Me.Master, Admin).UserMsgBox(ex.Message)
        Finally
            sqlConn.Close()
            sqlConn = Nothing
            sqlReader = Nothing
            sqlCmd = Nothing
        End Try

        If (sMessage <> "") Then
            CType(Me.Master, Admin).UserMsgBox(sMessage)
        End If

    End Sub
    'validate acivitiy form before save
    Public Function ValidateForm() As Boolean
        Dim sErrorMsg As String
        ValidateForm = True
        sErrorMsg = ""
        If TextProgramCode.Text.Trim() = "" Then
            ValidateForm = False
            TextProgramCode.Focus()
            sErrorMsg = "Please enter Program Code"
        ElseIf TextActivityID.Text.Trim() = "" Then
            ValidateForm = False
            TextActivityID.Focus()
            sErrorMsg = "Please enter Activity ID"
        ElseIf TextActivityCode.Text.Trim() = "" Then
            ValidateForm = False
            TextActivityCode.Focus()
            sErrorMsg = "Please enter Activity Code"
        End If
        If ValidateForm = False Then
            CType(Me.Master, Admin).UserMsgBox(sErrorMsg)
        End If

    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Not IsPostBack Then
            DDLHRType.SelectedIndex = 2
            DDLExamActivity.DataBind()
            CType(Me.Master, Admin).setDropdownList(Me.DDLExamActivity, "NO")
        End If
    End Sub

    Protected Sub ImageButtonSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonSearch.Click
        Dim sProgramCode As String
        Dim sActivityID As String
        Dim sActivityCode As String

        sProgramCode = TextProgramCode.Text.Trim()
        sActivityID = TextActivityID.Text.Trim()
        sActivityCode = TextActivityCode.Text.Trim()

        'If (sProgramCode = "" And sActivityID = "" ) Then
        'CType(Me.Master, Admin).UserMsgBox("Please enter Program Code or Activity ID or Both")
        ' Else

        If TextProgramCode.Text.Trim() = "" Then
            sProgramCode = " "
        End If
        If TextActivityID.Text.Trim() = "" Then
            sActivityID = " "
        End If
        If TextActivityCode.Text.Trim() = "" Then
            sActivityCode = " "
        End If
        SqlDataSourceDSCHRS.SelectParameters("MODE").DefaultValue = "SEARCH"
        SqlDataSourceDSCHRS.SelectParameters("PROGRAM_CODE").DefaultValue = sProgramCode
        SqlDataSourceDSCHRS.SelectParameters("ACTIVITY_ID").DefaultValue = sActivityID
        SqlDataSourceDSCHRS.SelectParameters("ACTIVITY_CODE").DefaultValue = sActivityCode

        GridViewAll.DataBind()
        PanelActivityAll.Visible = "true"
        'End If
    End Sub
    Public Sub ResetGridViewAll()
        SqlDataSourceDSCHRS.SelectParameters("MODE").DefaultValue = "SEARCH"
        SqlDataSourceDSCHRS.SelectParameters("PROGRAM_CODE").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("ACTIVITY_ID").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("ACTIVITY_CODE").DefaultValue = " "
        GridViewAll.DataBind()
    End Sub

End Class