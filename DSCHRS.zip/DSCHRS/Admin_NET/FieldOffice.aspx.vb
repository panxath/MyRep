﻿Imports System.Data.SqlClient
Imports System.Data

Public Class FieldOffice
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Public Sub ResetGridViewAll()
        SqlDataSourceDSCHRS.SelectParameters("FIELDOFFICE_CODE").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("DEPT_ID").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("DEPT_SHORT_DESC").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("DEPT_DESC").DefaultValue = " "
        SqlDataSourceDSCHRS.SelectParameters("ORG_CODE").DefaultValue = " "
        GridViewAll.DataBind()
    End Sub
    'Rest Field Office update form
    Public Sub resetFieldOfficeForm()
        TextNewUpdate.Text = "NEW"
        TextDeptID.Text = ""
        TextDeptID.ReadOnly = False
        TextDeptID.BackColor = Drawing.Color.Empty
        TextFieldOfficeCode.Text = ""
        TextDeptShortDesc.Text = ""
        TextDeptShortDesc.ReadOnly = False
        TextDeptShortDesc.BackColor = Drawing.Color.Empty
        TextDeptDesc.Text = ""
        TextDeptDesc.ReadOnly = False
        TextDeptDesc.BackColor = Drawing.Color.Empty
        TextOrgCode.Text = ""
        TextOrgCode.ReadOnly = False
        TextOrgCode.BackColor = Drawing.Color.Empty

        DDLDCACode.SelectedIndex = 0
        DDLRegion.SelectedIndex = 0
        DDLBUSLINE.SelectedIndex = 0
    End Sub
    'validate field office form before save
    Public Function ValidateForm() As Boolean
        Dim sErrorMsg As String
        ValidateForm = True
        sErrorMsg = ""
        If TextDeptID.Text.Trim() = "" Then
            ValidateForm = False
            TextDeptID.Focus()
            sErrorMsg = "Please enter Department ID"
        ElseIf TextFieldOfficeCode.Text.Trim() = "" Then
            ValidateForm = False
            TextFieldOfficeCode.Focus()
            sErrorMsg = "Please enter Field Office Code"
        ElseIf TextDeptShortDesc.Text.Trim() = "" Then
            ValidateForm = False
            TextDeptShortDesc.Focus()
            sErrorMsg = "Please enter Department Short Desc"
        ElseIf TextDeptDesc.Text.Trim() = "" Then
            ValidateForm = False
            TextDeptDesc.Focus()
            sErrorMsg = "Please enter Department Desc"
        ElseIf TextOrgCode.Text.Trim() = "" Then
            ValidateForm = False
            TextOrgCode.Focus()
            sErrorMsg = "Please enter Organization Code"
        ElseIf DDLRegion.SelectedIndex = 0 Then
            ValidateForm = False
            DDLRegion.Focus()
            sErrorMsg = "Please select Region"
        ElseIf DDLBUSLINE.SelectedIndex = 0 Then
            ValidateForm = False
            DDLBUSLINE.Focus()
            sErrorMsg = "Please Select Business Line"
        End If

        If ValidateForm = False Then
            CType(Me.Master, Admin).UserMsgBox(sErrorMsg)
        End If

    End Function

    Protected Sub ImageButtonSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonSearch.Click
        Dim sFieldOfficeCode As String
        Dim sDeptID As String
        Dim sDeptShortDesc As String
        Dim sDeptDesc As String
        Dim sOrgCode As String
        Dim sRegion As String
        Dim sBusline As String

        sFieldOfficeCode = TextFieldOfficeCode.Text.Trim()
        sDeptID = TextDeptID.Text.Trim()
        sDeptShortDesc = TextDeptShortDesc.Text.Trim()
        sDeptDesc = TextDeptDesc.Text.Trim()
        sOrgCode = TextOrgCode.Text.Trim()
        sRegion = DDLRegion.SelectedValue.Trim()
        sBusline = DDLBUSLINE.SelectedValue.Trim()

        If sFieldOfficeCode = "" Then
            sFieldOfficeCode = " "
        End If
        If sDeptID = "" Then
            sDeptID = " "
        End If
        If sDeptShortDesc = "" Then
            sDeptShortDesc = " "
        End If
        If sDeptDesc = "" Then
            sDeptDesc = " "
        End If
        If sOrgCode = "" Then
            sOrgCode = " "
        End If
        If sRegion = "" Then
            sRegion = " "
        End If
        If sBusline = "" Then
            sBusline = " "
        End If

        SqlDataSourceDSCHRS.SelectParameters("FIELDOFFICE_CODE").DefaultValue = sFieldOfficeCode
        SqlDataSourceDSCHRS.SelectParameters("DEPT_ID").DefaultValue = sDeptID
        SqlDataSourceDSCHRS.SelectParameters("DEPT_SHORT_DESC").DefaultValue = sDeptShortDesc
        SqlDataSourceDSCHRS.SelectParameters("DEPT_DESC").DefaultValue = sDeptDesc
        SqlDataSourceDSCHRS.SelectParameters("ORG_CODE").DefaultValue = sOrgCode
        SqlDataSourceDSCHRS.SelectParameters("REGION").DefaultValue = sRegion
        SqlDataSourceDSCHRS.SelectParameters("BUSLINE").DefaultValue = sBusline
        GridViewAll.DataBind()
        PanelFieldOfficeAll.Visible = True
    End Sub
    Protected Sub ImageButtonEmpty_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonEmpty.Click
        resetFieldOfficeForm()
        ResetGridViewAll()
        PanelFieldOfficeAll.Visible = False
    End Sub
    'click update for missing activity code
    Protected Sub GridViewToDo_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewToDo.RowCommand

        If (e.CommandName = "cmdAddAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetFieldOfficeForm()
            TextNewUpdate.Text = "NEW"
            TextDeptID.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextDeptID.ReadOnly = True
            TextDeptID.BackColor = Drawing.Color.DarkGray
            TextDeptShortDesc.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextDeptDesc.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(3).Text.Trim())
            TextOrgCode.Text = HttpUtility.HtmlDecode(GridViewToDo.Rows(currentRowIndex).Cells(4).Text.Trim())
            TextFieldOfficeCode.Focus()
        End If
    End Sub
    Protected Sub GridViewAll_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridViewAll.RowCommand

        If (e.CommandName = "cmdUpdAct") Then
            Dim currentRowIndex As Integer = Int32.Parse(e.CommandArgument.ToString())
            resetFieldOfficeForm()
            TextNewUpdate.Text = "UPDATE"
            TextDeptID.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(1).Text.Trim())
            TextDeptID.ReadOnly = True
            TextDeptID.BackColor = Drawing.Color.DarkGray
            TextFieldOfficeCode.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(2).Text.Trim())
            TextDeptShortDesc.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(3).Text.Trim())
            TextDeptDesc.Text = HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(4).Text.Trim())
            TextOrgCode.Text = GridViewAll.Rows(currentRowIndex).Cells(5).Text.Trim()

            CType(Me.Master, Admin).setDropdownList(Me.DDLDCACode, HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(7).Text.Trim()))
            CType(Me.Master, Admin).setDropdownList(Me.DDLRegion, HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(6).Text.Trim()))
            CType(Me.Master, Admin).setDropdownList(Me.DDLBUSLINE, HttpUtility.HtmlDecode(GridViewAll.Rows(currentRowIndex).Cells(8).Text.Trim()))
            TextFieldOfficeCode.Focus()
        End If


    End Sub

    Protected Sub ImageButtonInsert_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButtonInsert.Click
        If ValidateForm() = False Then
            Exit Sub
        End If

        Dim connString = ConfigurationManager.ConnectionStrings("DSCHRSConnectionString")
        Dim sqlConn As SqlConnection
        Dim sqlCmd As SqlCommand
        Dim sqlReader As SqlDataReader
        Dim sMessage As String
        Dim sActDesc As String
        Dim sResult As String


        sMessage = ""
        sActDesc = ""
        sResult = ""

        sqlConn = New SqlConnection()
        sqlConn.ConnectionString = connString.ConnectionString
        sqlConn.Open()
        sqlCmd = New SqlCommand()
        sqlCmd.CommandType = CommandType.StoredProcedure
        sqlCmd.Connection = sqlConn

        Try
            sqlCmd.CommandText = "P_INS_UPD_FLDOFC"
            sqlCmd.Parameters.AddWithValue("@Mode", TextNewUpdate.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@DEPTID", TextDeptID.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@FIELDOFFICECODE", TextFieldOfficeCode.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@DEPTSHORTDESC", TextDeptShortDesc.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@DEPTDESC", TextDeptDesc.Text.Trim())
            sqlCmd.Parameters.AddWithValue("@ORGCODE", TextOrgCode.Text.Trim())

            If DDLDCACode.SelectedValue.Trim() = "" Then
                sqlCmd.Parameters.AddWithValue("@DCAFLDOFCCODE", DBNull.Value)
            Else
                sqlCmd.Parameters.AddWithValue("@DCAFLDOFCCODE", DDLDCACode.SelectedValue.Trim())
            End If
            If DDLRegion.SelectedValue.Trim() = "" Then
                sqlCmd.Parameters.AddWithValue("@REGIONCODE", DBNull.Value)
            Else
                sqlCmd.Parameters.AddWithValue("@REGIONCODE", DDLRegion.SelectedValue.Trim())
            End If
            If DDLBUSLINE.SelectedValue.Trim() = "" Then
                sqlCmd.Parameters.AddWithValue("@BUSLNECDE", DBNull.Value)
            Else
                sqlCmd.Parameters.AddWithValue("@BUSLNECDE", DDLBUSLINE.SelectedValue.Trim())
            End If
            sqlReader = sqlCmd.ExecuteReader()
            If sqlReader.HasRows Then
                sqlReader.Read()
                sResult = sqlReader.GetString(0)
                sMessage = sqlReader.GetString(1)
            End If
            If sResult = "1" Then
                sMessage = "Data Saved Successfully"
                resetFieldOfficeForm()
                GridViewAll.DataBind()
                GridViewToDo.DataBind()
            Else
                If TextDeptID.ReadOnly Then
                    TextFieldOfficeCode.Focus()
                Else
                    TextDeptID.Focus()
                End If
            End If


        Catch ex As Exception
            CType(Me.Master, Admin).UserMsgBox(ex.Message)
        Finally
            sqlConn.Close()
            sqlConn = Nothing
            sqlReader = Nothing
            sqlCmd = Nothing
        End Try

        If (sMessage <> "") Then
            CType(Me.Master, Admin).UserMsgBox(sMessage)
        End If
    End Sub
End Class